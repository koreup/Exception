#include <iostream>
using namespace std;

int main() 
{
  try{  

          double num1=1;
          double num2=1;
          string word1;
          
          cout<<"enter number 1"<<endl;
          cin>>num1;
            
          cout<<"enter number 2"<<endl;
          cin>>num2;
          
          cout<<"enter any letter or word to continue"<<endl;
          cin>>word1;

            if(num1==0){
              cout<<0<<endl; }
            else if(num2==0) {
              throw 0;  }
            //"cant divide by zero"
            else if(word1=="stop") {
              throw 1;  }
            //"stop"
            else if(word1=="exit") {
              throw 2;  }
            //"exit"
          cout<<num1/num2<<endl;
          
      }catch(int x){
        cout<<x<<endl;
        if (x==0)
        cout<<"enter a valid value"<<endl;
        else if(x==1||x==2)
          cout<<"terminating keyword entered "<<endl;
      }
    
  return 0;
}