#include <iostream>
#include<string>
using namespace std;
void errCreator(){
    bool intError =false;
    bool strError =false;
    bool strObjError=true;
    if(intError){
        throw 110; // when error type is int
    }
    if(strError){
        throw "string"; //when error type is string
    }if(strObjError){
        throw string("string object!"); //when error type is string object created by string class
    }
}

int main()
{
    try{
        errCreator();
    }catch(int e){
        cout<<"Error message for type int: "<<e<<endl;
    }catch(char const * e){ // if type of error is string, we need to catch it w/ char const *(pointer)
        cout<<"Error message for type string: "<<e<<endl;
    }catch(string &e){ // catch an object with reference symbol "&"
        cout<<"Error message for type string object: "<<e<<endl;
    }
    return 0;
}
