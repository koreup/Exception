#include <iostream>

int main()
{
    char letrs[10];
    try {
        for(int i=0; i<=10; i++){
            if(i > 9)throw std::out_of_range("Array Out Of Bounds!" );
            letrs[i] = 'a';
            
        }
    }
    catch (char *str)
    {
        std::cout << "Exception" << str << std::endl;
    }
    return 0;
    
}

